import Vue from 'vue';
// eslint-disable-next-line
import VueRouter from 'vue-router';

const routesA = [
  {
    path: '/app1/one',
    name: 'compOne',
    component: {
      render(h) {
        return h('div', 'I am component one!');
      },
    },
  },
  {
    path: '/app1/two',
    name: 'compTwo',
    component: {
      render(h) {
        return h('div', 'I am component two!');
      },
    },
  },
];

const router = new VueRouter({
  routes: routesA,
});
//
router.beforeEach((to, from, next) => {
  next();
});
let domEl;
let vm;

function bootstrap(props) {
  const { name } = props;
  console.log(`${name} bootstrap!`);
  return Promise.resolve().then(() => {
    if (domEl) return;
    domEl = document.createElement('div');
    domEl.id = 'app1';
    document.body.appendChild(domEl);
    vm = new Vue({
      router,
      render(h) {
        return h('div', [h('h1', {
          on: {
            click() {
              const app2 = () => import('./app1.1');
              app2();
            },
          },
        }, 'I am app1'), h('router-view')]);
      },
      created() {
        console.log('vm created!');
      },
      destroyed() {
        console.log('vm destroyed!');
      },
    });
  });
}

function mount(props) {
  const { name } = props;
  console.log(`${name} mount!`);
  return Promise.resolve().then(() => {
    vm.$mount(domEl);
  });
}

function unmount(props) {
  const { name } = props;
  console.log(`${name} unmount!`);
  return Promise.resolve().then(() => {
    vm.$destroy();
    domEl.innerHTML = '';
  });
}

export default {
  bootstrap,
  mount,
  unmount,
};
