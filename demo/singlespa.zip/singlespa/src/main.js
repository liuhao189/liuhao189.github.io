import * as singleSpa from 'single-spa';

const appName = 'app1';

const loadingFunction = () => import('./app1.js');

const activityFunction = () => document.location.hash.startsWith('#/app1');

singleSpa.registerApplication(appName, loadingFunction, activityFunction);

singleSpa.start();
