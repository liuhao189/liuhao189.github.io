import Vue from 'vue';
// eslint-disable-next-line
import VueRouter from 'vue-router';
// eslint-disable-next-line
import Vuex from 'vuex';
const target = process.env.VUE_APP_TARGET;
if (target === 'dev') {
  Vue.use(VueRouter);
  Vue.use(Vuex);
}

const store = new Vuex.Store({
  state: {
    count: 0,
  },
  mutations: {
    increment(state) {
      state.count += 1;
    },
  },
});

const routesB = [
  {
    path: '/app2/one',
    component: {
      render(h) {
        return h('div', 'I am componet one in app2.');
      },
    },
  },
  {
    path: '/app2/two',
    component: {
      render(h) {
        return h('div', 'I am component two in app2.');
      },
    },
  },
];

const router = new VueRouter({
  routes: routesB,
});

let domel;
let appVm;

function bootstrap(props) {
  const { name } = props;
  console.log(`${name} bootstrap!`);
  domel = document.querySelector('#app2');
  if (!domel) {
    domel = document.createElement('div');
    domel.id = 'app2';
    document.body.appendChild(domel);
  }
  appVm = new Vue({
    router,
    store,
    render(h) {
      const self = this;
      let isActive = true;
      if (target !== 'dev') {
        const { mainStore } = window;
        const { activeApps } = mainStore.state;
        isActive = activeApps && activeApps.includes('app2');
      }
      return h('div', !isActive ? '' : [
        h('h1', {
          on: {
            click() {
              const app21 = () => import('./app2.1.js');
              app21();
            },
          },
        },
        `I am app two!Count is ${this.$store.state.count}`),
        h('button', {
          on: {
            click() {
              self.$store.commit('increment');
            },
          },
        }, 'increment'),
        h('router-view')]);
    },
  });
  return Promise.resolve();
}

function mount(props) {
  const { name } = props;
  console.log(`${name} mount!`);
  appVm.$mount(domel);
  return Promise.resolve();
}

function unmount(props) {
  const { name } = props;
  console.log(`${name} unmount!`);
  return Promise.resolve();
}

if (target === 'dev') {
  bootstrap().then(() => {
    mount();
  });
}


export default {
  bootstrap,
  mount,
  unmount,
};
