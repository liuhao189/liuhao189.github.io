let target = process.env.VUE_APP_TARGET;
//
module.exports = {
  configureWebpack: target === 'dev' ? undefined : {
    externals: {
      'vue': 'Vue',
      'vuex': 'Vuex',
      'vue-router': 'VueRouter'
    }
  }
}